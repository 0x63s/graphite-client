import './App.css'

function Header() {
    return (
        <>
        <div className="header">
            <h1>Chat App</h1>
            <UserAuth />
            <ServerStatus />
        </div>
        
        </>
    );
    }