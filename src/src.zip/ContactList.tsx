//import css
import './App.css';

<div className="contact-list">
    <ul>
        {/* Dynamically populate list items */}
    </ul>
</div>
